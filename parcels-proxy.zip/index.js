const express = require("express");
const fetch = require("node-fetch");
const cors = require("cors");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());

app.get("/track", async (req, res) => {
  const trackingNumber = req.query.number;

  if (!trackingNumber) {
    return res.status(400).json({ error: "Tracking number is required" });
  }

  try {
    const response = await fetch(`https://api.parcelsapp.com/v4/trackings/${trackingNumber}`, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${process.env.PARCELS_API_KEY}`,
        "Content-Type": "application/json"
      }
    });

    const data = await response.json();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch tracking info" });
  }
});

app.listen(PORT, () => {
  console.log(`Proxy server running on port ${PORT}`);
});